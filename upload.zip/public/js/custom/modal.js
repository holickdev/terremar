const target = document.getElementById('popup-modal');

const modal = new Modal(target);

modal.show();
